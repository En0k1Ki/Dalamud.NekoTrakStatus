# NekoTrak Status（FF14 卫月插件）

把 FF14 游戏内状态实时输出给 [NekoTrak](https://store.steampowered.com/app/5249210/NekoTrak/)（Steam 状态类桌宠，原 FlowTrak）。

本插件由 [goaaats/Dalamud.RichPresence](https://github.com/goaaats/Dalamud.RichPresence) 改造而来：
- 原版：每帧采集游戏状态（地图、职业、等级、世界、队伍、排队、AFK），通过 DiscordRPC 发给 Discord；
- 本版：采集同样的状态，改为写入**本地状态文件**（以及可选的 JSON 和游戏窗口标题），供 NekoTrak 读取展示。数据不离开本机。

## 为什么这样改（对接原理）

NekoTrak 是单人开发项目，没有公开的第三方数据 API，但它有两个现成的“外部数据入口”：

1. **自定义状态 + 命令行表达式**：NekoTrak 的自定义状态里可以嵌入命令行表达式，命令输出会动态放进状态文本（它自己的“CPU 占用”“当前时间”就是这么实现的）。
2. **应用状态规则 + 窗口标题**：NekoTrak 能按窗口标题匹配应用并显示自定义文本。

本插件把 FF14 状态写成一个文本文件，并可选地附加到 FF14 窗口标题上——正好覆盖这两条路。

## 使用方法

1. 用卫月插件安装器“从 zip 安装”`Dalamud.NekoTrakStatus-latest.zip`（见下方构建产物）。
2. 进游戏后用 `/nts` 打开设置。
3. 默认每秒把状态写入 `%AppData%\NekoTrak\ff14_status.txt`，例如：

   `海都甲板 · 龙骑 Lv90 · 幻影群岛 · 队伍 4/8 · 副本中`

4. 在 NekoTrak 里任选一种方式展示：

### 方式 A：自定义状态（命令行表达式）

在 NekoTrak 的“自定义状态”里添加一条，命令表达式为：

```
cmd /c type "%AppData%\NekoTrak\ff14_status.txt"
```

（表达式语法以 NekoTrak Demo 的编辑器为准；原理就是把文件内容打进状态。）

### 方式 B：窗口标题规则

1. 插件设置里勾选 **把状态附加到 FF14 窗口标题**（默认模板 `{territory} · {jobAbbr} Lv{level}`）。
2. 游戏窗口标题会变成：`FINAL FANTASY XIV ｜ 海都甲板 · 龙骑 Lv90`（退出游戏/关闭插件时自动还原）。
3. 在 NekoTrak 里为 FF14 添加一条“应用状态规则”，匹配该窗口标题即可。

### 其它工具

插件可同时写 `ff14_status.json`（同名文件），含全部结构化字段（地图 ID 之外的展示文本、排队位置、队伍人数等），任何工具都能读。

## 设置项

| 设置 | 说明 |
| --- | --- |
| 状态文件路径 | 默认 `%AppData%\NekoTrak\ff14_status.txt` |
| 同时写 JSON | 同名 `.json` 结构化数据 |
| 更新间隔 | 默认 1000ms，最小 100ms |
| 附加窗口标题 | 可选，模板可自定义 |
| 自定义文本模板 | 留空则按下方开关自动组合 |
| 显示角色名 / 部队标签 / 世界名 / 职业 / 缩写 / 等级 / 队伍 / AFK / 排队位置 | 与原版 RichPresence 同款开关（排队位置需安装 Waitingway） |
| 缩写用国服中文简称 | 默认开启：缩写显示为武士、龙骑、白魔等国服简称；关闭则显示游戏数据里的英文缩写（SAM、DRG、WHM） |

> 国服注意：游戏数据里职业的 Abbreviation 字段是英文且不本地化，所以勾选“职业名用缩写”后默认走内置的国服中文简称表；想要完整职业名（武士、龙骑士）就取消“职业名用缩写”。

### 自定义模板占位符

`{name}` `{world}` `{homeWorld}` `{companyTag}` `{territory}` `{region}` `{job}` `{jobAbbr}` `{level}` `{party}` `{partySize}` `{partyMax}` `{queue}` `{queueEta}` `{duty}` `{afk}` `{elapsed}`

例：`{territory} | {jobAbbr} Lv{level} | {world}{duty}{afk}`

## 与原版的差异

- **目标**：DiscordRPC（原版）→ 本地文件 / 窗口标题（本版），移除 Discord 依赖。
- **API**：原版是 net5.0 + 旧 Dalamud API（API 4/5 时代），已无法在当前 Dalamud 加载；本版按 **Dalamud API 15 + .NET 10** 重写（2026 年当前版本，遵循官方 SamplePlugin 模板结构）。
- **跨服小队人数**（原版用 FFXIVClientStructs 的 InfoProxy 读取）暂未移植；普通队伍与副本队伍人数正常。
- 如果想继续同步 Discord，可自行把 `DiscordPresenceManager`（原版文件）作为可选输出加回来。

## 构建

前置条件：

- .NET 10 SDK
- Dalamud 开发包：在 XIVLauncher 里开启“开发模式”自动获得，或下载
  `https://goatcorp.github.io/dalamud-distrib/latest.zip` 解压到
  `%AppData%\XIVLauncher\addon\Hooks\dev`（也可用环境变量 `DALAMUD_HOME` 指向该目录）。
- NuGet 包 `Dalamud.NET.Sdk 15.0.0`（联网环境自动还原；本仓库的 `nuget.config`
  指向本地源 `..\_tools\nuget-local`，离线构建可直接沿用）。

命令：

```
dotnet build -c Release
```

产物：`bin\Release\Dalamud.NekoTrakStatus\latest.zip`。

> 注意：Dalamud 随游戏版本更新，若未来 API 升级，把 csproj 里
> `Dalamud.NET.Sdk` 的版本号换成官方 SamplePlugin 对应的新版本即可。

## 文件结构

```
Dalamud.NekoTrakStatus.csproj   # 项目与插件 manifest 字段（SDK 自动生成 json）
Plugin.cs                       # 入口：事件挂接 + 状态采集（对应原版 RichPresencePlugin.cs）
StatusModel.cs                  # 状态模型 + 模板渲染
Configuration.cs                # 配置（IPluginConfiguration）
Managers/NekoTrakStatusManager.cs  # 输出：文本文件 / JSON / 窗口标题（替代原版 DiscordPresenceManager）
Managers/IpcManager.cs          # Waitingway 排队 IPC（原版同款）
Windows/ConfigWindow.cs         # /nts 设置窗口
icon.png
```

## 许可说明

- 原仓库 [goaaats/Dalamud.RichPresence](https://github.com/goaaats/Dalamud.RichPresence) 未附带 LICENSE 文件，公开传播前请注意其权利状态。
- NekoTrak 为独立项目，其 Demo/正式版的功能细节以开发者公告为准：
  [开发者公告（FlowTrak → NekoTrak）](https://www.vgover.com/news/237596)、
  [Steam 商店页](https://store.steampowered.com/app/5249210/NekoTrak/)。
