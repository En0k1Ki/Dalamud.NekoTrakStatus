using System;
using System.Diagnostics;
using System.IO;
using System.Numerics;

using Dalamud.Bindings.ImGui;
using Dalamud.Interface.Windowing;

namespace Dalamud.NekoTrakStatus.Windows;

internal sealed class ConfigWindow : Window, IDisposable
{
    private readonly Plugin plugin;

    private string statusFilePathInput = string.Empty;
    private string statusTemplateInput = string.Empty;
    private string windowTitleTemplateInput = string.Empty;
    private int updateIntervalInput;
    private bool inputSynced;

    public ConfigWindow(Plugin plugin)
        : base("NekoTrak Status 设置###NekoTrakStatusConfigWindow",
            ImGuiWindowFlags.NoResize | ImGuiWindowFlags.NoCollapse | ImGuiWindowFlags.NoScrollbar)
    {
        this.plugin = plugin;

        Size = new Vector2(600, 640);
        SizeCondition = ImGuiCond.FirstUseEver;
    }

    public void Dispose()
    {
    }

    public override void OnOpen()
    {
        inputSynced = false;
    }

    public override void Draw()
    {
        var cfg = plugin.Configuration;

        if (!inputSynced)
        {
            statusFilePathInput = cfg.StatusFilePath;
            statusTemplateInput = cfg.StatusTemplate;
            windowTitleTemplateInput = cfg.WindowTitleTemplate;
            updateIntervalInput = cfg.UpdateIntervalMs;
            inputSynced = true;
        }

        ImGui.TextWrapped("把 FF14 游戏内状态实时写入本地文件，供 NekoTrak 桌宠读取展示。");
        ImGui.TextWrapped($"当前状态：{plugin.LastStatusText ?? "（尚未更新）"}");
        ImGui.Separator();

        // ---- 输出设置 ----
        ImGui.TextUnformatted("输出设置");
        ImGui.Separator();

        var enabled = cfg.Enabled;
        if (ImGui.Checkbox("启用状态输出", ref enabled))
        {
            cfg.Enabled = enabled;
            cfg.Save();
        }

        if (ImGui.InputText("状态文件路径", ref statusFilePathInput, 1024))
        {
            cfg.StatusFilePath = statusFilePathInput;
            cfg.Save();
        }

        var writeJson = cfg.WriteJson;
        if (ImGui.Checkbox("同时写同名 .json 文件", ref writeJson))
        {
            cfg.WriteJson = writeJson;
            cfg.Save();
        }

        if (ImGui.InputInt("更新间隔（毫秒，最小 100）", ref updateIntervalInput))
        {
            cfg.UpdateIntervalMs = Math.Max(updateIntervalInput, 100);
            cfg.Save();
        }

        ImGui.Separator();

        var updateTitle = cfg.UpdateWindowTitle;
        if (ImGui.Checkbox("把状态附加到 FF14 窗口标题", ref updateTitle))
        {
            cfg.UpdateWindowTitle = updateTitle;
            cfg.Save();
        }

        if (ImGui.InputText("窗口标题模板", ref windowTitleTemplateInput, 512))
        {
            cfg.WindowTitleTemplate = windowTitleTemplateInput;
            cfg.Save();
        }

        ImGui.Separator();

        if (ImGui.InputText("自定义文本模板（留空 = 按下方开关自动组合）", ref statusTemplateInput, 1024))
        {
            cfg.StatusTemplate = statusTemplateInput;
            cfg.Save();
        }

        ImGui.TextWrapped("占位符：{name} {world} {homeWorld} {companyTag} {territory} {region} {job} {jobAbbr} {level} {party} {partySize} {partyMax} {queue} {queueEta} {duty} {afk} {elapsed}");
        ImGui.TextWrapped("NekoTrak 对接方式 A：自定义状态里用命令行表达式读取本文件，例如：cmd /c type \"文件路径\"");
        ImGui.TextWrapped("NekoTrak 对接方式 B：启用上面的窗口标题附加，然后在 NekoTrak 里为 FF14 添加“窗口标题规则”。");

        if (ImGui.Button("打开输出目录"))
        {
            TryOpenOutputDirectory(cfg.StatusFilePath);
        }

        ImGui.Separator();

        // ---- 显示内容 ----
        ImGui.TextUnformatted("显示内容（自动组合时生效）");
        ImGui.Separator();

        CheckboxSave(cfg, "显示角色名", cfg.ShowName, v => cfg.ShowName = v);
        CheckboxSave(cfg, "显示部队标签", cfg.ShowFreeCompany, v => cfg.ShowFreeCompany = v);
        CheckboxSave(cfg, "显示世界名", cfg.ShowWorld, v => cfg.ShowWorld = v);
        CheckboxSave(cfg, "显示职业", cfg.ShowJob, v => cfg.ShowJob = v);
        CheckboxSave(cfg, "职业名用缩写", cfg.AbbreviateJob, v => cfg.AbbreviateJob = v);
        CheckboxSave(cfg, "缩写用国服中文简称（武士、龙骑、白魔…）", cfg.UseChineseJobShorthand, v => cfg.UseChineseJobShorthand = v);
        CheckboxSave(cfg, "显示等级", cfg.ShowLevel, v => cfg.ShowLevel = v);
        CheckboxSave(cfg, "显示队伍人数", cfg.ShowParty, v => cfg.ShowParty = v);
        CheckboxSave(cfg, "显示离开（AFK）状态", cfg.ShowAfk, v => cfg.ShowAfk = v);
        CheckboxSave(cfg, "显示排队位置（需安装 Waitingway）", cfg.ShowLoginQueuePosition, v => cfg.ShowLoginQueuePosition = v);

        ImGui.Separator();

        if (ImGui.Button("保存并关闭"))
        {
            cfg.Save();
            IsOpen = false;
        }
    }

    private static void CheckboxSave(Configuration cfg, string label, bool value, Action<bool> set)
    {
        var copy = value;
        if (ImGui.Checkbox(label, ref copy))
        {
            set(copy);
            cfg.Save();
        }
    }

    private static void TryOpenOutputDirectory(string statusFilePath)
    {
        try
        {
            var dir = Path.GetDirectoryName(statusFilePath);
            if (string.IsNullOrEmpty(dir))
            {
                return;
            }

            Directory.CreateDirectory(dir);
            Process.Start(new ProcessStartInfo("explorer.exe", dir) { UseShellExecute = true });
        }
        catch (Exception)
        {
            // 打不开就不开，不影响功能
        }
    }
}
