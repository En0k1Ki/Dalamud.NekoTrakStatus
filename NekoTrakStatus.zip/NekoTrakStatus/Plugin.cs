using System;
using System.Collections.Generic;
using System.Linq;

using Dalamud.Game.ClientState.Objects.SubKinds;
using Dalamud.Game.Command;
using Dalamud.Interface.Windowing;
using Dalamud.IoC;
using Dalamud.Plugin;
using Dalamud.Plugin.Services;

using Lumina.Excel.Sheets;

using Dalamud.NekoTrakStatus.Managers;
using Dalamud.NekoTrakStatus.Windows;

namespace Dalamud.NekoTrakStatus;

/// <summary>
/// 把 FF14 游戏内状态（地图、职业、等级、世界、队伍、排队等）写入本地文件/窗口标题，
/// 供 NekoTrak 桌宠展示。由 goaaats/Dalamud.RichPresence 改造而来：
/// 原版把状态发给 Discord（DiscordRPC），本插件把同样的状态发给 NekoTrak 可读取的本地通道。
/// </summary>
public sealed class Plugin : IDalamudPlugin
{
    private const string CommandName = "/nts";

    [PluginService] internal static IDalamudPluginInterface PluginInterface { get; private set; } = null!;
    [PluginService] internal static IClientState ClientState { get; private set; } = null!;
    [PluginService] internal static ICommandManager CommandManager { get; private set; } = null!;
    [PluginService] internal static IDataManager DataManager { get; private set; } = null!;
    [PluginService] internal static IFramework Framework { get; private set; } = null!;
    [PluginService] internal static IPartyList PartyList { get; private set; } = null!;
    [PluginService] internal static IPlayerState PlayerState { get; private set; } = null!;
    [PluginService] internal static IObjectTable ObjectTable { get; private set; } = null!;
    [PluginService] internal static IPluginLog Log { get; private set; } = null!;

    public Configuration Configuration { get; init; }

    public string? LastStatusText => statusManager.LastText;

    internal readonly WindowSystem WindowSystem = new("NekoTrakStatus");

    private readonly ConfigWindow configWindow;
    private readonly NekoTrakStatusManager statusManager;
    private readonly IpcManager ipcManager;

    private readonly List<TerritoryType> territories;

    /// <summary>ClassJob RowId → 国服中文简称（游戏数据里的 Abbreviation 是英文且不本地化）。</summary>
    private static readonly Dictionary<uint, string> ChineseJobShorthand = new()
    {
        [1] = "剑术师", [2] = "格斗家", [3] = "斧术师", [4] = "枪术师", [5] = "弓箭手",
        [6] = "幻术师", [7] = "咒术师", [8] = "刻木匠", [9] = "锻铁匠", [10] = "铸甲匠",
        [11] = "雕金匠", [12] = "裁衣匠", [13] = "制革匠", [14] = "炼金术士", [15] = "烹调师",
        [16] = "采矿工", [17] = "园艺工", [18] = "捕鱼人",
        [19] = "骑士", [20] = "武僧", [21] = "战士", [22] = "龙骑", [23] = "诗人",
        [24] = "白魔", [25] = "黑魔", [26] = "秘术师", [27] = "召唤", [28] = "学者",
        [29] = "双剑师", [30] = "忍者", [31] = "机工", [32] = "暗骑", [33] = "占星",
        [34] = "武士", [35] = "赤魔", [36] = "青魔", [37] = "绝枪", [38] = "舞者",
        [39] = "镰刀", [40] = "贤者", [41] = "蝰蛇", [42] = "画家",
    };

    private DateTime zoneStart = DateTime.UtcNow;
    private long lastUpdateTick;

    public Plugin()
    {
        Configuration = PluginInterface.GetPluginConfig() as Configuration ?? new Configuration();

        statusManager = new NekoTrakStatusManager(Configuration, Log);
        ipcManager = new IpcManager();

        configWindow = new ConfigWindow(this);
        WindowSystem.AddWindow(configWindow);

        PluginInterface.UiBuilder.Draw += WindowSystem.Draw;
        PluginInterface.UiBuilder.OpenConfigUi += ToggleConfigUi;
        PluginInterface.UiBuilder.OpenMainUi += ToggleConfigUi;

        CommandManager.AddHandler(CommandName, new CommandInfo(OnCommand)
        {
            HelpMessage = "打开 NekoTrak Status 设置窗口",
        });

        Framework.Update += OnFrameworkUpdate;
        ClientState.Login += OnLogin;
        ClientState.Logout += OnLogout;
        ClientState.TerritoryChanged += OnTerritoryChanged;

        territories = DataManager.GetExcelSheet<TerritoryType>()?.ToList() ?? new List<TerritoryType>();
    }

    public void Dispose()
    {
        Framework.Update -= OnFrameworkUpdate;
        ClientState.Login -= OnLogin;
        ClientState.Logout -= OnLogout;
        ClientState.TerritoryChanged -= OnTerritoryChanged;

        CommandManager.RemoveHandler(CommandName);

        PluginInterface.UiBuilder.Draw -= WindowSystem.Draw;
        PluginInterface.UiBuilder.OpenConfigUi -= ToggleConfigUi;
        PluginInterface.UiBuilder.OpenMainUi -= ToggleConfigUi;

        WindowSystem.RemoveAllWindows();
        configWindow.Dispose();
        statusManager.Dispose();
        ipcManager.Dispose();
    }

    public void ToggleConfigUi() => configWindow.Toggle();

    private void OnCommand(string command, string args) => configWindow.Toggle();

    private void OnLogin() => zoneStart = DateTime.UtcNow;

    private void OnTerritoryChanged(uint territoryId) => zoneStart = DateTime.UtcNow;

    private void OnLogout(int type, int code) => zoneStart = DateTime.UtcNow;

    private void OnFrameworkUpdate(IFramework framework)
    {
        if (!Configuration.Enabled)
        {
            return;
        }

        var interval = Math.Max(Configuration.UpdateIntervalMs, 100);
        var now = Environment.TickCount64;
        if (now - lastUpdateTick < interval)
        {
            return;
        }

        lastUpdateTick = now;

        try
        {
            statusManager.Update(BuildStatus());
        }
        catch (Exception ex)
        {
            Log.Error(ex, "NekoTrakStatus: 更新状态时发生错误");
        }
    }

    private StatusModel BuildStatus()
    {
        var cfg = Configuration;
        var model = new StatusModel();

        var player = ObjectTable.LocalPlayer;

        // 角色未加载：要么在登录排队，要么在角色选择界面
        if (player is null)
        {
            if (cfg.ShowLoginQueuePosition && ipcManager.IsInLoginQueue())
            {
                var position = ipcManager.GetQueuePosition();
                if (position >= 0)
                {
                    model.InQueue = true;
                    model.QueuePosition = position;
                    model.QueueEta = ipcManager.GetQueueEstimate();
                }
            }

            model.InMenus = !model.InQueue;
            return model;
        }

        model.PlayerName = player.Name.ToString();
        model.CompanyTag = player.CompanyTag.ToString();
        model.Afk = PlayerState.IsAwayFromKeyboard;
        model.Level = player.Level;

        model.World = PlayerState.CurrentWorld.Value.Name.ToString();
        model.HomeWorld = PlayerState.HomeWorld.Value.Name.ToString();
        model.VisitingOtherWorld = PlayerState.CurrentWorld.RowId != PlayerState.HomeWorld.RowId;

        model.Job = PlayerState.ClassJob.Value.Name.ToString();
        model.JobAbbreviation = GetJobShorthand();

        var territoryId = ClientState.TerritoryType;
        if (territoryId != 0)
        {
            var territory = territories.FirstOrDefault(t => t.RowId == territoryId);
            if (territory.RowId == territoryId)
            {
                model.Territory = territory.PlaceName.Value.Name.ToString();
                model.Region = territory.PlaceNameRegion.Value.Name.ToString();
            }
        }

        if (cfg.ShowParty && PartyList.Length > 0 && PartyList.PartyId != 0)
        {
            var cfc = DataManager.GetExcelSheet<ContentFinderCondition>()?
                .FirstOrDefault(x => x.TerritoryType.RowId == territoryId);

            var partyMax = cfc is { ContentType.RowId: 2 } ? 4 : 8;
            if (PartyList.Length > partyMax)
            {
                partyMax = PartyList.Length;
            }

            model.PartySize = PartyList.Length;
            model.PartyMax = partyMax;
            model.InDuty = cfc != null;
        }

        model.ZoneElapsed = DateTime.UtcNow - zoneStart;
        return model;
    }

    private string GetJobShorthand()
    {
        if (Configuration.UseChineseJobShorthand &&
            ChineseJobShorthand.TryGetValue(PlayerState.ClassJob.RowId, out var shorthand))
        {
            return shorthand;
        }

        return PlayerState.ClassJob.Value.Abbreviation.ToString();
    }
}
