using System;
using System.Collections.Generic;
using System.Text;

namespace Dalamud.NekoTrakStatus;

/// <summary>
/// 一次游戏状态快照。可渲染为文本（模板占位符）或序列化为 JSON。
/// </summary>
internal sealed class StatusModel
{
    public string? PlayerName { get; set; }
    public string? World { get; set; }
    public string? HomeWorld { get; set; }
    public string? CompanyTag { get; set; }
    public bool VisitingOtherWorld { get; set; }

    public string? Territory { get; set; }
    public string? Region { get; set; }

    public string? Job { get; set; }
    public string? JobAbbreviation { get; set; }
    public int Level { get; set; }

    public bool InDuty { get; set; }
    public int PartySize { get; set; } = -1;
    public int PartyMax { get; set; }

    public bool Afk { get; set; }

    public bool InQueue { get; set; }
    public int QueuePosition { get; set; } = -1;
    public TimeSpan? QueueEta { get; set; }

    public bool InMenus { get; set; }
    public TimeSpan ZoneElapsed { get; set; }

    private static readonly string[] Placeholders =
    {
        "{name}", "{world}", "{homeWorld}", "{companyTag}", "{territory}", "{region}",
        "{job}", "{jobAbbr}", "{level}", "{party}", "{partySize}", "{partyMax}",
        "{queue}", "{queueEta}", "{duty}", "{afk}", "{elapsed}",
    };

    private string? GetValue(string placeholder) => placeholder switch
    {
        "{name}" => PlayerName,
        "{world}" => World,
        "{homeWorld}" => HomeWorld,
        "{companyTag}" => CompanyTag,
        "{territory}" => Territory,
        "{region}" => Region,
        "{job}" => Job,
        "{jobAbbr}" => JobAbbreviation,
        "{level}" => Level > 0 ? Level.ToString() : null,
        "{party}" => PartySize >= 0 ? $"{PartySize}/{PartyMax}" : null,
        "{partySize}" => PartySize >= 0 ? PartySize.ToString() : null,
        "{partyMax}" => PartyMax > 0 ? PartyMax.ToString() : null,
        "{queue}" => QueuePosition >= 0 ? QueuePosition.ToString() : null,
        "{queueEta}" => QueueEta?.ToString(@"h\:mm\:ss"),
        "{duty}" => InDuty ? "（副本中）" : null,
        "{afk}" => Afk ? "（离开）" : null,
        "{elapsed}" => ZoneElapsed.ToString(@"hh\:mm\:ss"),
        _ => null,
    };

    /// <summary>把模板中的占位符替换为当前状态。</summary>
    public string Render(string template)
    {
        var sb = new StringBuilder(template);
        foreach (var placeholder in Placeholders)
        {
            sb.Replace(placeholder, GetValue(placeholder) ?? string.Empty);
        }

        return sb.ToString().Trim();
    }

    /// <summary>未配置自定义模板时，按显示开关自动组合一行文本（尽量还原原版 RichPresence 的排版逻辑）。</summary>
    public string RenderDefault(Configuration cfg)
    {
        if (InQueue && cfg.ShowLoginQueuePosition)
        {
            var eta = QueueEta is { } e && e.TotalSeconds >= 1 ? $"，预计 {e:h\\:mm\\:ss}" : string.Empty;
            return $"排队中：第 {QueuePosition} 位{eta}";
        }

        if (InMenus)
        {
            return "游戏内（未登录）";
        }

        var parts = new List<string>();

        // 第一段：角色名（或地图名）
        if (cfg.ShowName && !string.IsNullOrEmpty(PlayerName))
        {
            var name = PlayerName;
            if (cfg.ShowFreeCompany && !VisitingOtherWorld && !string.IsNullOrEmpty(CompanyTag))
            {
                name = $"{name} «{CompanyTag}»";
            }
            else if (cfg.ShowWorld && VisitingOtherWorld && !string.IsNullOrEmpty(HomeWorld))
            {
                name = $"{name} ❀ {HomeWorld}";
            }

            parts.Add(name);
        }
        else if (!string.IsNullOrEmpty(Territory))
        {
            parts.Add(Territory);
        }

        // 第二段：世界（或地图/区域）
        if (cfg.ShowWorld)
        {
            if (!string.IsNullOrEmpty(World))
            {
                parts.Add(World);
            }
        }
        else
        {
            var place = cfg.ShowName ? Territory : Region;
            if (!string.IsNullOrEmpty(place))
            {
                parts.Add(place);
            }
        }

        // 地图（与角色名同时显示时补上地图）
        if (cfg.ShowName && !string.IsNullOrEmpty(Territory) && !cfg.ShowWorld)
        {
            // 上面第二段已经补了地图，这里不再重复
        }
        else if (cfg.ShowName && cfg.ShowWorld && !string.IsNullOrEmpty(Territory))
        {
            parts.Add(Territory);
        }

        // 职业与等级
        if (cfg.ShowJob)
        {
            var job = cfg.AbbreviateJob && !string.IsNullOrEmpty(JobAbbreviation) ? JobAbbreviation : Job;
            if (!string.IsNullOrEmpty(job))
            {
                parts.Add(cfg.ShowLevel && Level > 0 ? $"{job} Lv{Level}" : job);
            }
        }

        // 队伍
        if (cfg.ShowParty && PartySize >= 0)
        {
            parts.Add($"队伍 {PartySize}/{PartyMax}");
        }

        if (InDuty)
        {
            parts.Add("副本中");
        }

        if (cfg.ShowAfk && Afk)
        {
            parts.Add("离开");
        }

        return parts.Count > 0 ? string.Join(" · ", parts) : "游戏中";
    }
}
