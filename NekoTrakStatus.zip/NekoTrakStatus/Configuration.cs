using System;
using System.IO;

using Dalamud.Configuration;

namespace Dalamud.NekoTrakStatus;

[Serializable]
public class Configuration : IPluginConfiguration
{
    public int Version { get; set; } = 1;

    // ---- 输出目标 ----
    public bool Enabled { get; set; } = true;

    /// <summary>状态文本文件路径。默认放到 NekoTrak 的数据目录旁（%AppData%\NekoTrak\ff14_status.txt）。</summary>
    public string StatusFilePath { get; set; } = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "NekoTrak", "ff14_status.txt");

    /// <summary>同时写一个同名 .json 文件（结构化数据，供其它工具使用）。</summary>
    public bool WriteJson { get; set; } = true;

    /// <summary>状态采集/写入间隔（毫秒）。</summary>
    public int UpdateIntervalMs { get; set; } = 1000;

    /// <summary>是否把状态附加到 FF14 窗口标题上（NekoTrak 的“窗口标题规则”可读取）。</summary>
    public bool UpdateWindowTitle { get; set; } = false;

    /// <summary>窗口标题模板。默认 {territory} · {jobAbbr} Lv{level}</summary>
    public string WindowTitleTemplate { get; set; } = "{territory} · {jobAbbr} Lv{level}";

    /// <summary>自定义文本模板。留空则按下方开关自动组合。</summary>
    public string StatusTemplate { get; set; } = string.Empty;

    // ---- 显示内容开关（与原 Discord Rich Presence 一致） ----
    public bool ShowName { get; set; } = true;
    public bool ShowFreeCompany { get; set; } = true;
    public bool ShowWorld { get; set; } = true;
    public bool ShowJob { get; set; } = true;
    public bool AbbreviateJob { get; set; } = true;

    /// <summary>缩写使用国服中文简称（武士、龙骑、白魔…），而不是游戏数据里的英文缩写（SAM、DRG、WHM…）。</summary>
    public bool UseChineseJobShorthand { get; set; } = true;
    public bool ShowLevel { get; set; } = true;
    public bool ShowParty { get; set; } = true;
    public bool ShowAfk { get; set; } = true;
    public bool ShowLoginQueuePosition { get; set; } = true;

    public void Save() => Plugin.PluginInterface.SavePluginConfig(this);
}
