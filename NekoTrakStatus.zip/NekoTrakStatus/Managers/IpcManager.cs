using System;

using Dalamud.Plugin.Ipc;
using Dalamud.Plugin.Ipc.Exceptions;

namespace Dalamud.NekoTrakStatus.Managers;

/// <summary>
/// Waitingway 插件的 IPC，用于获取登录排队位置（原版 RichPresence 同款逻辑）。
/// </summary>
internal sealed class IpcManager : IDisposable
{
    private readonly ICallGateSubscriber<bool> wwIsInQueue;
    private readonly ICallGateSubscriber<int> wwGetQueueType;
    private readonly ICallGateSubscriber<int> wwGetQueuePosition;
    private readonly ICallGateSubscriber<TimeSpan?> wwGetQueueEstimate;

    public IpcManager()
    {
        wwIsInQueue = Plugin.PluginInterface.GetIpcSubscriber<bool>("Waitingway.IsInQueue");
        wwGetQueueType = Plugin.PluginInterface.GetIpcSubscriber<int>("Waitingway.GetQueueType");
        wwGetQueuePosition = Plugin.PluginInterface.GetIpcSubscriber<int>("Waitingway.GetQueuePosition");
        wwGetQueueEstimate = Plugin.PluginInterface.GetIpcSubscriber<TimeSpan?>("Waitingway.GetQueueEstimate");
    }

    public bool IsInLoginQueue()
    {
        try
        {
            // 只关心登录排队（type == 1），不关心副本排本
            return wwIsInQueue.InvokeFunc() && wwGetQueueType.InvokeFunc() == 1;
        }
        catch (IpcNotReadyError)
        {
            return false;
        }
    }

    public int GetQueuePosition()
    {
        try
        {
            return wwGetQueuePosition.InvokeFunc();
        }
        catch (IpcNotReadyError)
        {
            return -1;
        }
    }

    public TimeSpan? GetQueueEstimate()
    {
        try
        {
            return wwGetQueueEstimate.InvokeFunc();
        }
        catch (IpcNotReadyError)
        {
            return null;
        }
    }

    public void Dispose()
    {
    }
}
