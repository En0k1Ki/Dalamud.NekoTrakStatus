using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;

using Dalamud.Plugin.Services;

namespace Dalamud.NekoTrakStatus.Managers;

/// <summary>
/// 把游戏状态写出到本地：
/// 1) 状态文本文件（NekoTrak 自定义状态的“命令行表达式”可用 cmd /c type 读取）；
/// 2) 可选同名 JSON 文件；
/// 3) 可选把状态附加到 FF14 窗口标题（NekoTrak 的“窗口标题规则”可读取）。
/// </summary>
internal sealed class NekoTrakStatusManager : IDisposable
{
    private readonly Configuration config;
    private readonly IPluginLog log;

    private string? lastText;
    private string? lastJson;
    private string? lastTitle;

    private IntPtr gameHwnd;
    private string? originalTitle;
    private bool titleApplied;

    private DateTime lastErrorLog = DateTime.MinValue;

    public string? LastText => lastText;

    [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern bool SetWindowTextW(IntPtr hWnd, string text);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int GetWindowTextW(IntPtr hWnd, StringBuilder text, int maxCount);

    public NekoTrakStatusManager(Configuration config, IPluginLog log)
    {
        this.config = config;
        this.log = log;
    }

    public void Update(StatusModel status)
    {
        var text = string.IsNullOrWhiteSpace(config.StatusTemplate)
            ? status.RenderDefault(config)
            : status.Render(config.StatusTemplate);

        if (text != lastText)
        {
            lastText = text;
            TryWriteFile(config.StatusFilePath, text);
        }

        if (config.WriteJson)
        {
            var json = JsonSerializer.Serialize(status, new JsonSerializerOptions
            {
                WriteIndented = true,
                Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
            });

            if (json != lastJson)
            {
                lastJson = json;
                TryWriteFile(GetJsonPath(config.StatusFilePath), json);
            }
        }

        if (config.UpdateWindowTitle)
        {
            var title = status.Render(config.WindowTitleTemplate);
            if (title != lastTitle)
            {
                lastTitle = title;
                ApplyWindowTitle(title);
            }
        }
        else if (titleApplied)
        {
            RestoreWindowTitle();
        }
    }

    private void TryWriteFile(string path, string content)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(path))
            {
                return;
            }

            var dir = Path.GetDirectoryName(path);
            if (!string.IsNullOrEmpty(dir))
            {
                Directory.CreateDirectory(dir);
            }

            // 先写临时文件再原子替换，避免 NekoTrak 读到写了一半的内容
            var tmp = path + ".tmp";
            File.WriteAllText(tmp, content, new UTF8Encoding(false));
            File.Move(tmp, path, true);
        }
        catch (Exception ex)
        {
            LogThrottled(ex, $"NekoTrakStatus: 写入状态文件失败 {path}");
        }
    }

    private static string GetJsonPath(string path) => Path.ChangeExtension(path, ".json");

    private void ApplyWindowTitle(string suffix)
    {
        try
        {
            if (gameHwnd == IntPtr.Zero)
            {
                using var process = Process.GetCurrentProcess();
                gameHwnd = process.MainWindowHandle;
                if (gameHwnd == IntPtr.Zero)
                {
                    return; // 主窗口还没创建，下个周期再试
                }
            }

            if (!titleApplied)
            {
                var sb = new StringBuilder(512);
                GetWindowTextW(gameHwnd, sb, sb.Capacity);
                originalTitle = sb.ToString();
                titleApplied = true;
            }

            var newTitle = string.IsNullOrEmpty(suffix) ? originalTitle ?? string.Empty : $"{originalTitle} ｜ {suffix}";
            SetWindowTextW(gameHwnd, newTitle);
        }
        catch (Exception ex)
        {
            LogThrottled(ex, "NekoTrakStatus: 设置 FF14 窗口标题失败");
        }
    }

    private void RestoreWindowTitle()
    {
        if (!titleApplied || gameHwnd == IntPtr.Zero)
        {
            titleApplied = false;
            lastTitle = null;
            return;
        }

        try
        {
            if (originalTitle != null)
            {
                SetWindowTextW(gameHwnd, originalTitle);
            }
        }
        catch (Exception ex)
        {
            LogThrottled(ex, "NekoTrakStatus: 恢复 FF14 窗口标题失败");
        }
        finally
        {
            titleApplied = false;
            lastTitle = null;
        }
    }

    private void LogThrottled(Exception ex, string message)
    {
        if ((DateTime.UtcNow - lastErrorLog).TotalSeconds < 30)
        {
            return;
        }

        lastErrorLog = DateTime.UtcNow;
        log.Error(ex, message);
    }

    public void Dispose()
    {
        RestoreWindowTitle();
    }
}
